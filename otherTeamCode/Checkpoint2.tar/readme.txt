compile on linux.cs.tamu.edu with the given makefile
after compliing enther the command
export LD_LIBRARY_PATH=:LD_LIBRARY_PATH
